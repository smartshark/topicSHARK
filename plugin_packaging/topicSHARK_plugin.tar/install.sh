#!/bin/sh
cd ${1}
python3.5 ${1}/setup.py install --user
